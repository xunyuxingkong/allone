@echo off

REM Copyright (c) 2002-2025 XuGuWeiYe Technologies Co., Ltd.  All rights reserved.
REM XuGuDB server console runner script for Windows

SET server=127.0.0.1
SET port=5138
SET ssl_str=nssl
SET database=SYSTEM
SET username=SYSDBA
SET password=SYSDBA

"%~dp0/xgconsole.exe" -s %ssl_str% -P %port% -h %server% -d "%database%" -u "%username%" -p "%password%"
