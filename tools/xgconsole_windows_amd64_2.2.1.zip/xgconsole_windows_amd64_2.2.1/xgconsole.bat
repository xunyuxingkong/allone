@echo off

REM Copyright (c) 2002-2025 XuGuWeiYe Technologies Co., Ltd.  All rights reserved.
REM XuGuDB server console runner script for Windows

SET server=127.0.0.1
SET /P server="Server [%server%]: "

SET port=5138
SET /P port="Port [%port%]: "

SET ssl_str=nssl
SET /P ssl_str="SSL [%ssl_str%]: "

SET database=SYSTEM
SET /P database="Database [%database%]: "

SET username=SYSDBA
SET /P username="Username [%username%]: "

REM Run xgconsole
"%~dp0/xgconsole.exe" -s %ssl_str% -P %port% -h %server% -d "%database%" -u "%username%"
pause
