#!/bin/bash
# > connectDB -local location

echo "Copyright (c) 2002-2025 XuGuWeiYe Technologies Co., Ltd.  All rights reserved."
echo "XuGuDB server console runner script for Linux"

server=127.0.0.1
port=5138
ssl_str=nssl
database=SYSTEM
username=SYSDBA
password=SYSDBA

"$PWD/xgconsole" -s $ssl_str -P $port -h $server -d $database -u "$username" -p "$password"
